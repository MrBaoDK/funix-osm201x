#!/bin/bash

readonly output_file="final_ex5.txt"
# clear output_file
> $output_file

file_names=("pre_a_exe5.txt" "pre_b_exe5.txt" "pre_c_exe5.txt")
total_fail=0
total_pass=0
total_notcheck=0
sums=()
for i in "${!file_names[@]}"; do
  while IFS= read -r line || [[ -n "$line" ]]; do
    IFS=": " read -a splitLine <<< "$line"
    key="${splitLine[0]}"
    value="${splitLine[1]}"
    case $key in
      "PASS") total_pass=$(($total_pass+ $value));;
      "FAIL") total_fail=$(($total_fail+ $value));;
      "NOTCHECK") total_notcheck=$(($total_notcheck+ $value));;
    esac
    sums[$i]=$((${sums[$i]}+ $value))
  done < "${file_names[$i]}"
done

echo "FAIL: $total_fail" >> $output_file
echo "PASS: $total_pass" >> $output_file
echo "NOTCHECK: $total_notcheck" >> $output_file
echo "**********" >> $output_file
echo "SUM1: ${sums[0]}" >> $output_file
echo "SUM2: ${sums[1]}" >> $output_file
echo "SUM3: ${sums[2]}" >> $output_file
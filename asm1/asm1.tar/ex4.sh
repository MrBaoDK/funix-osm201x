#!/bin/sh

# read fileName
# fileName=$1
fileName="note.txt"

outFilename="output.txt"
echo -n > $outFilename
echo -n "Input a number n="
read n

count=1
while IFS= read -r line; do
  if [ $(($count % 2)) = 0 ]; then
    echo "$count. $line" >> $outFilename
  fi
  if [ $count -gt $n ]; then
    echo "$count. $line"
  fi
  count=$(($count+1))
done < $fileName
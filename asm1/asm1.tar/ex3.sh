#!/bin/bash

dfStr=$(df)
echo "List of all filesystem"
allFS=""
lt80=""
while IFS= read -r line; do
  IFS=' ' read -a splitLine <<< "$line"
  usedCapacityStr=${splitLine[4]}
  usedCapacity=${usedCapacityStr/"%"/""}
  allFS+=" ${splitLine[0]}"
  if [[ $usedCapacity -gt 20 ]]
  then
    lt80+="${splitLine[0]}  "
  fi
done <<< "$dfStr"
echo "$allFS"
if [[ ${#lt80} -gt 0 ]]
then
  echo "$lt80 have less than 80% free space"
else
  echo "No Filesystem have less than 80% freespace"
fi
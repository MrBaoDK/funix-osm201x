#!/bin/sh

echo $(TZ="Asia/Ho_Chi_Minh" date)
echo
echo "Process:"
echo
ps
echo
echo "Memory usage:"
echo
free -h
echo
echo "CPU load:"
echo
uptime
echo
echo "Kernel version is:"
echo
uname -r
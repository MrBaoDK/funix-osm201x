#!/bin/sh

echo "Enter first number:"
read firstNumber
echo "Enter second number:"
read secondNumber
total=$(($firstNumber+$secondNumber))
echo "Sum: $firstNumber + $secondNumber = $total"